
. .\MetersOnDemand.ps1

$MetersOnDemand

# TODO: Better tests skull

Help

Version

Update-SkinList -Cache $MetersOnDemand.Cache -Force

Search -Query "reisir"

New-Lock "Mondtholomew"

New-Package "Mondtholomew"

Get-SkinObject "meters-on-demand/cli"

$response = Get-Request "$($MetersOnDemand.Api.Endpoints.Skins)"

Get-MondInc -RootConfig "Meters on Demand"

Get-SkinInfo -RootConfig "Meters on Demand"

Test-BuiltIn "PowershellRM"
Test-BuiltIn "WebParser"
